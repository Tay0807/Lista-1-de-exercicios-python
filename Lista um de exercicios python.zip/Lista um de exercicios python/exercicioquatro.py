nome = str(input("Insira seu nome: "))
idade = int(input("Insira sua idade: "))

if idade < 18:
    print(f"{nome}, você é menor de idade")
elif idade >= 18 and idade <= 65:
    print(f"{nome}, você é adulto")
else:
    print(f"{nome}, você é idoso(a)")