num = input("Insira um número inteiro: ")
result = 0
# transformou em número
numInicio = int(num)

for digito in len(num):
    result += (int(digito) * int(digito) * int(digito))
    
if numInicio == result: 
    print("É um numero de armstrong") 
else: 
    print("Não é um número Armstrong")



