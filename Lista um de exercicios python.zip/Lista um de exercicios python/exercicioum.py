def soma(a,b):
    return a + b

def subtracao(a,b):
    return a - b

def divisao(a,b):
    return a / b


def multiplicacao(a,b):
    return a * b

repita = True

while repita == True:
    num = float(input("Digite o primeiro número: "))
    num2 = float(input("Digite o segundo número: "))
    
    rep = True
    while rep == True:
        rep = False
        result = int(input("Escolha uma operação: 1 para soma, 2 para subtração, 3 para divisão e 4 para multiplicação."))
        if result == 1:
            print(soma(num,num2))
        elif result == 2:
            print(subtracao(num,num2))
        elif result == 3:
            print(divisao(num,num2))
        elif result == 4:
            print(multiplicacao(num,num2))
        else:
            print("Essa operação não é válida")
            rep = True
        
repetir = int(input("Deseja fazer outra conta? 1 para sim e 2 para não: "))
    
if repetir == 2:
   repita == False
