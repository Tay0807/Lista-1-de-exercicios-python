num = int(input("Insira a primeira nota: "))
num2 = int(input("Insira a segunda nota: "))
num3 = int(input("Insira a terceira nota: "))
result = ( num + num2 + num3)/3

if result >= 7:
    print("Aprovada(o)!")
elif result <= 5 and result < 6:
    print("Recuperação!")
else:
    print("Reprovado!")