s = float(input("Insira seu salário: "))
 

if s <= 1500:
    result = (s * 0.10) + s
    dif = result - s
    print(f"Seu sálario era {s} e agora aumentou para: {result}. Você teve um aumento de: {dif}")
else:
    result = (s * 0.05) + s
    dif = result - s
    print(f"Seu slário era {s} e agora aumentou para: {result}. Você teve um aumento de: {dif}")