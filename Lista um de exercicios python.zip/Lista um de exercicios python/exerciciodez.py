print ("Insira três números inteiros: ")

numum = int(input("Insira o primeiro número: \n"))
numdois = int(input("Insira o segundo número: \n"))
numtres = int(input("Insira o terceiro número: \n"))

lista = [
    numum,
    numdois,
    numtres
]
# sort ordena os números
lista.sort()
print(lista)

     