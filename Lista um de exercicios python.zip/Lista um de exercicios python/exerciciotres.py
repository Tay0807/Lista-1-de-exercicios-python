numero = int(input("Informe um número: "))
div = numero - 1
primo = True

while div > 1:
    if(numero % div == 0):
        print("Não é primo")
        primo = False
        break
    
    div = div - 1

if primo:
    print("É primo")