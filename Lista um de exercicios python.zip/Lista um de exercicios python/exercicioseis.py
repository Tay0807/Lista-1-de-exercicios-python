num = int(input("Digite um número de 3 dígitos: "))
soma = 0
if len(num) != 3:
    print("Número inválido")
else:
    while num > 0:
        soma += num % 10
        num = num // 10
        print("A soma dos dígitos é:", soma)
