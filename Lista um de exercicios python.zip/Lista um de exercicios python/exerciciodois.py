while True:

    rep = True
    while rep:

        meses = [
            "Janeiro",
            "Fevereiro",
            "Marco",
            "Abril",
            "Maio",
            "Junho",
            "Julho",
            "Agosto",
            "Setembro",
            "Outubro",
            "Novembro",
            "Dezembro"
        ]

        mes = int(input("Insira um número: "))

        if mes > 0 and mes < 13:
            print(meses[mes - 1])
        else:
            print("Mês inválido")
            rep = False

    repetir = int(input("Deseja colocar outro número? 1 para sim e 2 para não: "))
    
    if repetir == 2:
        break