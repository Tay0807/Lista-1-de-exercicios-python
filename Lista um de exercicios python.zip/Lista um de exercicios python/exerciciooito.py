idade = int(input("Digite a sua idade: "))
cigarros_por_dia = int(input("Digite a quantidade de cigarros que você fuma por dia: "))

tempo_de_vida_restante = 75 - idade
minutos_restantes = tempo_de_vida_restante * 365 * 24 * 60 - (cigarros_por_dia * 10 * 365 * idade)
horas_restantes = int(minutos_restantes / 60)
minutos_restantes = int(minutos_restantes % 60)
dias_restantes = int(horas_restantes / 24)
horas_restantes = int(horas_restantes % 24)
anos_restantes = int(tempo_de_vida_restante)
meses_restantes = int((tempo_de_vida_restante - anos_restantes) * 12)

print("Você ainda tem", anos_restantes, "anos,", meses_restantes, "meses,", dias_restantes, "dias e", horas_restantes, "horas de vida pela frente.")
